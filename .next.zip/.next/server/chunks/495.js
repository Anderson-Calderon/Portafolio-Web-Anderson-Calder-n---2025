"use strict";
exports.id = 495;
exports.ids = [495];
exports.modules = {

/***/ 7495:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "i": () => (/* binding */ PortafolioProvider)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
//COMPONENETES DE REACT


//CREAMOS EL CONTEXT
const ContextPortafolio = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();
const PortafolioProvider = ({ children  })=>{
    //UTILIZAMOS PARA MOSTRAR EL MENÚ Y OCULTARLO
    const [menuVisible, setMenuVisible] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    // LO UTILIZO PARA SABER SI HICE CLICK EN ALGÚN DETERMINADO ENLACE . 
    //POR EJEMPLO SI HAGO CLICK EN EL ENLACE trabajos , ENTONCES PINTO EL ENLACE ACTIVO.
    const [trabajos, setTrabajos] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [contacto, setContacto] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [habilidades, setHabilidades] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [yo, setYo] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [clickEnLinkContacto, setClickEnLinkContacto] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(ContextPortafolio.Provider, {
        value: {
            menuVisible,
            setMenuVisible,
            clickEnLinkContacto,
            setClickEnLinkContacto,
            trabajos,
            setTrabajos,
            contacto,
            setContacto,
            yo,
            setYo,
            habilidades,
            setHabilidades
        },
        children: children
    });
};

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ContextPortafolio);


/***/ })

};
;