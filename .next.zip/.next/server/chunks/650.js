"use strict";
exports.id = 650;
exports.ids = [650];
exports.modules = {

/***/ 6650:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ components_Habilidades)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: external "TagCloud"
var external_TagCloud_ = __webpack_require__(1354);
var external_TagCloud_default = /*#__PURE__*/__webpack_require__.n(external_TagCloud_);
;// CONCATENATED MODULE: ./components/TextShpere.js




const TextShpere = ()=>{
    (0,external_react_.useEffect)(()=>{
        const container = ".tagcloud";
        const texts = [
            "REACT.JS",
            "NODE.JS",
            "JS",
            "JQUERY",
            "HTML5",
            "CSS3",
            "TAILWIND",
            "WORDPRESS",
            "ELEMENTOR",
            "WOOCOMMERCE",
            "PHP",
            "BOOTSTRAP 5",
            "SQL SERVER",
            "MYSQL",
            "SQL SERVER",
            "GOOGLE WORK SPACE",
            "CRM KOMMO",
            "CPANEL",
            "GOOGLE SEARCH CONSOLE",
            "GOOGLE TAG MANAGER",
            "WIX"
        ];
        const options = {
            radius: 150,
            maxSpeed: "fast",
            initSpeed: "fast",
            keep: true
        };
        // return ()=>{									
        external_TagCloud_default()(container, texts, options);
    // }	  
    }, []);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: "text-shpere w-50",
            children: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                className: "tagcloud w-50"
            })
        })
    });
};
/* harmony default export */ const components_TextShpere = (TextShpere);

;// CONCATENATED MODULE: ./components/Habilidades.js


//COMPONENETE QUE CONTIENE MIS HÁBILIDADES

//REACT

const Habilidades = ({ textoTitulo  })=>{
    const arregloLetras = textoTitulo.split("");
    let i = 0;
    (0,external_react_.useEffect)(()=>{
        let titulo2 = document.querySelector(".habilidades h2 ");
        let letrasTitulo2 = document.querySelectorAll(".habilidades h2 span");
        //BIEN CARGA LA PÁGINA ANIMAMOS LAS LETRAS DEL TITULO , SIEMPRE Y CUANDO ESTEMOS VISUALIZANDO
        //ESTE TÍTULO.
        animarLetras(letrasTitulo2);
        function animarLetras(letras) {
            for(var i = 0; i < letras.length; i++){
                let alturaAnimado = letras[i].offsetTop;
                letras[i].classList.add("letra", "letra-" + i);
            }
        }
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "md:w-1/2",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        children: arregloLetras.map((letra)=>{
                            i++;
                            return /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                className: "",
                                children: letra
                            }, i);
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        className: "text-justify",
                        children: "Soy desarrollador web con experiencia en la creaci\xf3n de sitios y soluciones digitales adaptadas a distintas necesidades. Poseo s\xf3lidos conocimientos en Shopify, WordPress, Elementor, WooCommerce, Wix, HTML5, CSS3, Bootstrap, Tailwind, JavaScript, React.js, Node.js y PHP. Adem\xe1s, manejo herramientas como CRM Kommo, Google Workspace, Make Scenarios, Google Tag Manager, Clarity, Google Search Console y plataformas de pauta digital. Me apasiona la programaci\xf3n y disfruto creando soluciones innovadoras a trav\xe9s de mis l\xedneas de c\xf3digo."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_TextShpere, {})
        ]
    });
};
/* harmony default export */ const components_Habilidades = (Habilidades);


/***/ })

};
;